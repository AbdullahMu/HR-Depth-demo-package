# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['depth_estimation']
setup_kwargs = {
    'name': 'depth-estimation',
    'version': '0.1.1',
    'description': 'High Resolution Self-Supervised Monocular Depth Estimation',
    'long_description': None,
    'author': 'Abdullah AlGhamdi',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '<=3.7',
}


setup(**setup_kwargs)
